#!/usr/bin/env python

#-------------------------------------------------------------------
#--- Node:   drive_kobki
#--- Author: Tom Swift
#--- Created: 2/21/2023
#---
#--- This node controls the movement of the kobuki robot, driving
#--- it forward, left and right as a simulation of a falling
#--- CANSAT.
#--- The commands the node can receive are straight, left, right
#--- and stop.  The robot's forward linear velocity will always be
#--- constant and the angular velocity will be varied to make the
#--- robot go left or right.  Zeroing the angular velocity will
#--- make the robot go straight.
#---
#--- A shutdown callback and a bumper event callback are implemented
#--- to make sure the robot gets stopped in case it hits something.
#--------------------------------------------------------------------
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose
from kobuki_msgs.msg import BumperEvent

cmd_msg = Twist()
cmd_vel_topic = '/mobile_base/commands/velocity'
bumper_topic = '/mobile_base/events/bumper'
cmd_vel_pub = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)


def shutdown_hook():
    #--- Make sure robot is stopped.
    stop()

def bumper_callback(data):
    if data.state == BumperEvent.PRESSED:
        stop()

def forward():
    cmd_msg.linear.x = 0.3
    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)

def stop():
    cmd_msg.linear.x = 0.0
    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)
    rospy.loginfo('Stopping Path')

def left():
    cmd_msg.angular.z += 0.075
    cmd_vel_pub.publish(cmd_msg)

def right():
    cmd_msg.angular.z -= 0.075
    cmd_vel_pub.publish(cmd_msg)


def main():
    rospy.init_node('main')
    rate = rospy.Rate(10)  # 10hz
    rospy.on_shutdown(shutdown_hook)
    bumper_sub = rospy.Subscriber(bumper_topic, BumperEvent, bumper_callback)
    rospy.loginfo('Beginning Path')
    
    #--- The stages are just a way to control the movement. The
    #--- stage_count is a way of implementing a timer. Each
    #--- time through the while loop, the stage_count is
    #--- decremented. When the stage_count reaches zero, the
    #--- stage is bumped to the next stage and the stage_count
    #--- is set to a number for the time of the next stage.
    #--- Each stage causes a different movement.
    stage = 1
    stage_count = 30    # 3 seconds for first stage

    while not rospy.is_shutdown():
        #--- First pass, put in a string of commands
        if 1 == stage:
	    forward()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 2
                stage_count = 7
            rate.sleep()

        elif 2 == stage:
            right()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 3
                stage_count = 7
            rate.sleep()

        elif 3 == stage:
            right()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 4
                stage_count = 15
            rate.sleep()

        elif 4 == stage:
            forward()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 5
                stage_count = 7
            rate.sleep()

        elif 5 == stage:
            left()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 6
                stage_count = 7
            rate.sleep()

        elif 6 == stage:
            left()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 7
                stage_count = 15
            rate.sleep()

        elif 7 == stage:
            forward()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 8
                stage_count = 7
            rate.sleep()

        elif 8 == stage:
            right()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 9
                stage_count = 20
            rate.sleep()

        elif 9 == stage:
            forward()
            if stage_count > 0:
                stage_count -= 1
            else: 
                stage = 10
                stage_count = 10
            rate.sleep()

	else:
	    stop()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

