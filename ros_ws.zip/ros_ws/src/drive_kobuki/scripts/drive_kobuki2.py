#!/usr/bin/env python

#-------------------------------------------------------------------
#--- Node:   drive_kobki2
#--- Author: Tom Swift
#--- Created: 3/14/2023
#---
#--- This node controls the movement of the kobuki robot, driving
#--- it forward, left and right as a simulation of a falling
#--- CANSAT.
#--- The commands the node can receive are straight, left, right
#--- and stop.  The robot's forward linear velocity will always be
#--- constant and the angular velocity will be varied to make the
#--- robot go left or right.  Zeroing the angular velocity will
#--- make the robot go straight.
#---
#--- The commands will come in on the /chatter topic from the Arduino.
#---
#--- A shutdown callback and a bumper event callback are implemented
#--- to make sure the robot gets stopped.
#--------------------------------------------------------------------
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose
from kobuki_msgs.msg import BumperEvent

cmd_msg = Twist()
cmd_vel_topic = '/mobile_base/commands/velocity'
bumper_topic = '/mobile_base/events/bumper'
cmd_vel_pub = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)
arduino_cmd = ""


def shutdown_hook():
    #--- Make sure robot is stopped.
    stop()

def bumper_callback(data):
    if data.state == BumperEvent.PRESSED:
        stop()

def forward():
    rospy.loginfo('Forward')
    #--- Ramp up speed and setup  to be called again.
    if cmd_msg.linear.x < 0.3:
        cmd_msg.linear.x += 0.1
        arduino_cmd = "forward"
    cmd_msg.angular.z = 0.0

def stop():
    cmd_msg.linear.x = 0.0
    cmd_msg.angular.z = 0.0
    rospy.loginfo('Stopping Path')

def left():
    rospy.loginfo('Right')
    cmd_msg.angular.z += 0.075

def right():
    rospy.loginfo('Right')
    cmd_msg.angular.z -= 0.075


#-----------------------------------------
#--- The callback implement all the logic.
#-----------------------------------------
def arduino_msg_callback(data):
    global arduino_cmd
    arduino_cmd = data.data
#    rospy.loginfo(arduino_cmd)

#---------------------------------------
#--- This is the main loop.
#---------------------------------------
def listener():
    global arduino_cmd
    rospy.init_node('listener', anonymous=True)
    rospy.on_shutdown(shutdown_hook)
    bumper_sub = rospy.Subscriber(bumper_topic, BumperEvent, bumper_callback)
    rospy.loginfo('Beginning Path')

    rospy.Subscriber("chatter", String, arduino_msg_callback)

    while not rospy.is_shutdown():
#        rospy.loginfo('Inside Loop %s',arduino_cmd)

        if arduino_cmd == "forward":
            arduino_cmd = ""    # Important that this is before forward()
            forward()
        elif arduino_cmd == "right":
            arduino_cmd = ""
            right()
        elif arduino_cmd == "left":
            arduino_cmd = ""
            left()
        elif arduino_cmd == "stop":
            arduino_cmd = ""
            stop()
        elif arduino_cmd == "":
            #--- Nothing to do here, just keep running the same command.
#            rospy.loginfo('Empty Command')
            arduino_cmd = ""
        else:
            #--- Unknown command so print error message and stop
            rospy.loginfo(rospy.get_caller_id() + "Stopping: unknown command: %s", data.data)
            arduino_cmd = ""
            stop()

        #--- Publish the command that was updated or just the same one again.
        cmd_vel_pub.publish(cmd_msg)


if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass

