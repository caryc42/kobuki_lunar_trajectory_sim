#!/usr/bin/env python

#-------------------------------------------------------------------
#--- Node:   test_forward
#--- Author: Tom Swift
#--- Created: 2/21/2023
#---
#--- This node controls publishes a twist message to the cmd_vel topic
#--- and just makes the robot go forward.
#--------------------------------------------------------------------
import rospy
from std_msgs.msg import String, Empty
from geometry_msgs.msg import Twist, Pose
from kobuki_msgs.msg import BumperEvent
from kobuki_msgs.msg import Led
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from time import time

cmd_msg = Twist()
cmd_vel_topic = '/mobile_base/commands/velocity'
cmd_vel_pub = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)

bumper_topic = '/mobile_base/events/bumper'
                   
odom_topic = '/odom'

imu_topic = '/mobile_base/sensors/imu_data'

led_msg = Led()
led_topic = '/mobile_base/commands/led2'
led1_topic = '/mobile_base/commands/led1'
led_pub = rospy.Publisher(led_topic, Led, queue_size=10)
led1_pub = rospy.Publisher(led1_topic, Led, queue_size=10)

x = -0.01
y = -0.01
rotx = 0.0
roty = 0.0
rotz = 0.0
imuz = 0.0
bEvent = False

def shutdown_hook():
    #--- Make sure robot is stopped.
    stop()

def bumper_callback(data):
    if data.state == BumperEvent.PRESSED:
        print("Bumber!!!")
        bEvent = True
        stop()

def ledOnOff(aState):
    if aState == 1:
        led_msg.value = Led.RED
        print("Thinks its on")
    else:
        led_msg.value = Led.BLACK
        print("Thinks its off")

    led_pub.publish(led_msg)
    led1_pub.publish(led_msg)


def stop():
    cmd_msg.linear.x = 0.0
    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)
    rospy.loginfo('Stopping Path')
    ledOnOff(0)

def forward():
#    rospy.loginfo('Forward')
    cmd_msg.linear.x = 0.2
#    cmd_msg.linear.y = -0.15
    cmd_msg.angular.z = -0.22
    cmd_vel_pub.publish(cmd_msg)

def read_odom(data):
    global x,y,rotx,roty,rotz

    x = data.pose.pose.position.x * 1000
    y = data.pose.pose.position.y * 1000
    rotx = data.pose.pose.orientation.x
    roty = data.pose.pose.orientation.y
    rotz = data.pose.pose.orientation.z
    

def reset_odom():
    reset_odom_topic = '/mobile_base/commands/reset_odometry'
    reset_odom_pub = rospy.Publisher(reset_odom_topic, Empty, queue_size=10)
    
    timer = time()
#    while time() - timer < 0.30:
    while x != 0.0 or y != 0.0:
        reset_odom_pub.publish(Empty())
#        timer = time()        

def read_imu(data):
    global imuz
    imuz = data.orientation.z
        

def listener():
    rospy.init_node('listener', anonymous=True)
    rate = rospy.Rate(10)  # 10hz
    rospy.on_shutdown(shutdown_hook)
    bumper_sub = rospy.Subscriber(bumper_topic, BumperEvent, bumper_callback)
    odom_sub = rospy.Subscriber('/odom', Odometry, read_odom)
    imu_sub = rospy.Subscriber(imu_topic, Imu, read_imu)
    rospy.loginfo('Beginning Path')

    reset_odom()

    ledOnOff(1)

    count = 0

    try:
        while count <= 170 and bEvent == False:
            print("x: %.2f y: %.2f"%(x,y))
            print("rotz: %.5f imuz: %.5f"%(rotz,imuz))
            count +=1
            forward()
       
            rate.sleep()
    except KeyboardInterrupt:
        print("Keyboard Interrupt")
    finally:
        stop()

if __name__ == '__main__':
    listener()
