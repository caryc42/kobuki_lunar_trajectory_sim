#!/usr/bin/env python

#-------------------------------------------------------------------
#--- Node:   test_forward
#--- Author: Tom Swift
#--- Created: 2/21/2023
#---
#--- This node controls publishes a twist message to the cmd_vel topic
#--- and just makes the robot go forward.
#--------------------------------------------------------------------
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose
from kobuki_msgs.msg import BumperEvent

cmd_msg = Twist()
cmd_vel_topic = '/mobile_base/commands/velocity'
bumper_topic = '/mobile_base/events/bumper'
cmd_vel_pub = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)

def shutdown_hook():
    #--- Make sure robot is stopped.
    stop()

def bumper_callback(data):
    if data.state == BumperEvent.PRESSED:
        stop()

def stop():
    cmd_msg.linear.x = 0.0
    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)
    rospy.loginfo('Stopping Path')

def max_speed():
    rospy.loginfo('Forward')
    cmd_msg.linear.x = 1.0
    cmd_msg.angular.z = -0.5
    cmd_vel_pub.publish(cmd_msg)


def forward():
    rospy.loginfo('Forward')
    cmd_msg.linear.x = 0.3
    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)


#-------------------------------------------
#--- This function makes the angular speed
#--- zero so that it only goes forward.  If
#--- the robot is starting from a stopped 
#--- state, the forward speed is ramped up.
#-------------------------------------------
def ramp_up():
#    rospy.loginfo('Forward')
    #--- Ramp up speed and setup to be called again.
    if cmd_msg.linear.x < 1.1:
        cmd_msg.linear.x += 0.01

    cmd_msg.angular.z = 0.0
    cmd_vel_pub.publish(cmd_msg)
    


#-------------------------------------------
#--- This function makes the angular speed
#--- zero so that it only goes forward. The
#--- speed is ramped down to zero and then 
#--- the robot is stopped.
#-------------------------------------------
def ramp_down():
#    rospy.loginfo('Forward')
    #--- Ramp down speed
    if cmd_msg.linear.x > 0:
        cmd_msg.linear.x -= 0.05
        cmd_msg.angular.z = -0.5
        cmd_vel_pub.publish(cmd_msg)
        robot_stopped =False 
    else:
        stop()
        robot_stopped = True

    return robot_stopped


#-----------------------------------------
#--- This is the main program.
#-----------------------------------------
def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.on_shutdown(shutdown_hook)
    bumper_sub = rospy.Subscriber(bumper_topic, BumperEvent, bumper_callback)
    rate = rospy.Rate(10)  # 10hz
    rospy.loginfo('Beginning Path')
    robot_stopped = False

    while not rospy.is_shutdown() and not robot_stopped:
    
    	for i in range(20):
            max_speed()
            rate.sleep()

        print("Start ramp down")

#        for i in range(20):
#            cmd_vel_pub.publish(cmd_msg)
#            rate.sleep()
    	    
        print("End of steady state")

    	for i in range(51):
    	    robot_stopped = ramp_down()
            rate.sleep()

        print("End of ramp down")
    	    
        rospy.spin()


if __name__ == '__main__':
    listener()
